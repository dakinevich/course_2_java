import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        task4(args);
    }
    private static void task1(String[] args){
        FootballMatch fm = new FootballMatch();
    }
    private static void task2(String[] args){
        RandomShapes.main(args);
    }
    private static void task3(String[] args){
        ImageWindow.main(new String[] {"Practice_5/src/1.jpg",});
    }
    private static void task4(String[] args){
        AnimationWindow.main(args);
    }

}

// В main методе создаем переменную и выводим всю информацию о ней
