public class Main {
    public static void main(String[] args) {
        //Practise 5.RandomShapes
        RandomShapes.main(args);
    }
}