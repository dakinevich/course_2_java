public interface myComparable<T> {
    public int compareTo(T comparable);
}
