public class MVCPatternDemo2 {
}
