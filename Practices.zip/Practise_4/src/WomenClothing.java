interface WomenClothing {
    void dressWomen();
}