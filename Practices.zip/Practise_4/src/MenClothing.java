interface MenClothing {
    void dressMan();
}
