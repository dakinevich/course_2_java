public interface StringWork {
    public int countStrSymbols(String s);
    public String evenSymbols(String s);
    public String invert(String s);

}
