public interface MathCalculate {
    float Pi = 3.1415f;
    public float[] pow(float r, float i, int times);
    public float abs(float r, float i);
    public float[] multiply(float r1, float i1, float r2, float i2);

}
