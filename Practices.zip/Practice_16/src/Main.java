public class Main {
    public static void main(String[] args) {
        /*GuessingGame game = new GuessingGame();
        game.setVisible(true);*/

        //Zones z = new Zones();

        PassCheck passwordChecker = new PassCheck();
        passwordChecker.setVisible(true);
    }
}